public class Cabin extends Passenger{
    private String cusName;
    public Cabin (){}

    public void setCusName(String cusName) {
        this.cusName = cusName;
    }

    public String getCusName() {
        return cusName;
    }
}
